<?php
if (!defined('ABSPATH'))
	exit;
class DfdHeaderBuilder_Form_Mobile extends DfdHeaderBuilder_Form_FormGenerator {

	public function getName() {
		return "mobile";
	}

}
