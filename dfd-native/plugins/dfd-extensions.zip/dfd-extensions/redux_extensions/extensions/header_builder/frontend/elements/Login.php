<?php
if (!defined('ABSPATH'))
	exit;
class DfdHeaderBuilder_Login extends DfdHeaderBuilderElementAbstract {

	protected $option_name = "header_login";
	protected $template = "login";

}
