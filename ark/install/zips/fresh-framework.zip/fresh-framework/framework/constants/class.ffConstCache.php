<?php

class ffConstCache {
    const CACHED_OPTIONS_NAMESPACE = 'cached_options';
    const CACHED_OPTIONS_INTERVAL_CHECK = 2419200; //60 * 60 * 24 * 7 * 4;
    const CACHED_OPTIONS_MAXIMUM_FILE_AGE = 2419200; // 60 * 60 * 24 * 7 * 4;
}