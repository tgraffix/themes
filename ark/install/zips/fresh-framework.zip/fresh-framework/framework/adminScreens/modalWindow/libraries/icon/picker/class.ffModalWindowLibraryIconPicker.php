<?php

class ffModalWindowLibraryIconPicker extends ffModalWindow {
	protected function _initialize() {
		$this->_setMenuName('Select Icon <a href="http://arktheme.com/academy/tutorial/icon-library/" class="aa-help aa-help--type-1" target="_blank" title="Watch Video Lesson"></a>');
	}
}