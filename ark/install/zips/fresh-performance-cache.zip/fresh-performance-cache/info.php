<?php

$info = array();
$info['plugin-name'] = 'fresh-performance-cache';
$info['plugin-version'] = '1.2.0';