<?php

$info = array();
$info['plugin-name'] = 'fresh-menu-item-limit-fix';
$info['plugin-version'] = '1.0.0';