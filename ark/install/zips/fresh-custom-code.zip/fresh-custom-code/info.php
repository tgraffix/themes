<?php
 
$info = array();
$info['plugin-name'] = 'fresh-custom-code';
$info['plugin-version'] = '1.3.2';